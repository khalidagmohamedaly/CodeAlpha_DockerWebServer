# CodeAlpha_DockerWebServer

**Stage DevOps — Tâche 4 : Web Server using Docker**

Serveur web Node.js/Express conteneurisé avec Docker, démontrant les bases de la conteneurisation, le cycle de vie d'un conteneur, le monitoring via health-check et les bonnes pratiques de déploiement.

## 📁 Structure du projet

```
CodeAlpha_DockerWebServer/
├── app/
│   ├── server.js          # Serveur Express
│   ├── package.json
│   └── test.js             # Tests d'intégration locaux
├── .github/workflows/
│   └── ci.yml              # CI : build + healthcheck automatique
├── Dockerfile               # Build multi-stage (sécurisé, image légère)
├── docker-compose.yml
├── .dockerignore
└── README.md
```

## 🚀 Démarrage rapide

### Sans Docker (test direct de l'app)
```bash
cd app
npm install
npm start          # démarre sur http://localhost:3000
npm test           # lance la suite de tests
```

### Avec Docker

```bash
# Build de l'image
docker build -t codealpha-webserver:1.0.0 .

# Lancer le conteneur
docker run -d --name codealpha_webserver -p 3000:3000 codealpha-webserver:1.0.0

# Ou plus simple, avec Docker Compose
docker compose up -d --build
```

L'application est accessible sur **http://localhost:3000**.

## 🔍 Endpoints disponibles

| Méthode | Route              | Description                          |
|---------|--------------------|---------------------------------------|
| GET     | `/`                 | Page d'accueil + uptime               |
| GET     | `/health`           | Health check (utilisé par Docker)     |
| GET     | `/api/info`         | Infos système du conteneur            |
| GET     | `/api/echo/:msg`    | Echo de test                          |

## 🐳 Cycle de vie du conteneur (commandes essentielles)

```bash
docker ps                              # Conteneurs en cours d'exécution
docker logs -f codealpha_webserver     # Suivre les logs en temps réel
docker exec -it codealpha_webserver sh # Ouvrir un shell dans le conteneur
docker stats codealpha_webserver       # CPU / mémoire en temps réel
docker inspect codealpha_webserver     # Détails complets (réseau, volumes, healthcheck)
docker stop codealpha_webserver        # Arrêt propre
docker start codealpha_webserver       # Redémarrage
docker rm -f codealpha_webserver       # Suppression forcée
```

## 🩺 Monitoring & Troubleshooting

- Le `HEALTHCHECK` intégré au Dockerfile interroge `/health` toutes les 30s.
  Statut visible directement dans `docker ps` (colonne `STATUS` : `healthy` / `unhealthy`).
- Si le conteneur est `unhealthy` :
  1. `docker logs codealpha_webserver` pour voir la stack trace.
  2. `docker exec -it codealpha_webserver sh` puis `wget -O- http://localhost:3000/health` pour tester depuis l'intérieur.
  3. Vérifier que le port 3000 n'est pas déjà utilisé sur l'hôte (`lsof -i :3000`).
- Les logs sont limités à 10 Mo / 3 fichiers (`json-file` driver) pour éviter de saturer le disque.

## 🔒 Bonnes pratiques appliquées

- **Build multi-stage** : l'image finale ne contient pas les outils de build, seulement le runtime.
- **Utilisateur non-root** (`appuser`) : limite l'impact en cas de compromission du conteneur.
- **Image de base Alpine** : surface d'attaque réduite, image plus légère (~50 Mo vs ~900 Mo pour une image Node complète).
- **`.dockerignore`** : évite de copier `node_modules`, `.git`, etc. dans le contexte de build.
- **`restart: unless-stopped`** : redémarrage automatique du conteneur en cas de crash, sauf arrêt volontaire.

## ✅ CI/CD

Le workflow `.github/workflows/ci.yml` build l'image et vérifie automatiquement le health check à chaque push/PR sur `main`.

## 📤 Pour la soumission CodeAlpha

```bash
git init
git add .
git commit -m "Initial commit - Docker Web Server"
git branch -M main
git remote add origin https://github.com/<ton-username>/CodeAlpha_DockerWebServer.git
git push -u origin main
```
